﻿using System;
using System.Windows.Forms;
using AromaDom.Forms;
using AromaDom.Services;

namespace AromaDom
{
    internal static class Program
    {
        [STAThread]
        private static void Main()
        {
            ApplicationConfiguration.Initialize();

            try
            {
                DatabaseService databaseService = new DatabaseService();
                databaseService.EnsureDatabaseInitialized();
                MainForm mainForm = new MainForm(databaseService);
                Application.Run(mainForm);
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    $"Критическая ошибка запуска приложения:
{ex.Message}

" +
                    "Порядок исправления:
Убедитесь, что файл aroma_dom.db или db_script.sql находится в папке приложения.",
                    "Ошибка инициализации",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }
    }
}
