﻿using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace AromaDom
{
    public static class AppTheme
    {
        public static readonly Color PrimaryBackground = ColorTranslator.FromHtml("#FFFFFF");

        public static readonly Color SecondaryBackground = ColorTranslator.FromHtml("#F4E6D4");

        public static readonly Color AccentColor = ColorTranslator.FromHtml("#8A5A44");

        public static readonly Color TextColor = ColorTranslator.FromHtml("#2B1E19");

        public static Font CreateFont(float sizePt, FontStyle style = FontStyle.Regular)
        {
            return new Font("Georgia", sizePt, style);
        }

        public static void ApplyWindowIcon(Form targetForm)
        {
            string iconPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Resources", "icon.ico");
            if (File.Exists(iconPath))
            {
                targetForm.Icon = new Icon(iconPath);
            }
        }

        public static Button CreateAccentButton(string caption, int width = 190, int height = 38)
        {
            Button button = new Button();
            button.Text = caption;
            button.Width = width;
            button.Height = height;
            button.BackColor = AccentColor;
            button.ForeColor = Color.White;
            button.FlatStyle = FlatStyle.Flat;
            button.FlatAppearance.BorderSize = 0;
            button.Font = CreateFont(10.5f, FontStyle.Bold);
            button.Cursor = Cursors.Hand;
            return button;
        }

        public static Button CreateSecondaryButton(string caption, int width = 140, int height = 36)
        {
            Button button = new Button();
            button.Text = caption;
            button.Width = width;
            button.Height = height;
            button.BackColor = PrimaryBackground;
            button.ForeColor = AccentColor;
            button.FlatStyle = FlatStyle.Flat;
            button.FlatAppearance.BorderColor = AccentColor;
            button.FlatAppearance.BorderSize = 1;
            button.Font = CreateFont(10f, FontStyle.Regular);
            button.Cursor = Cursors.Hand;
            return button;
        }
    }
}
