﻿namespace AromaDom.Models
{
    public class MaterialTypeItem
    {
        public int Id { get; set; }

        public string Name { get; set; } = string.Empty;

        public double LossPercent { get; set; }

        public override string ToString()
        {
            return Name;
        }
    }
}
