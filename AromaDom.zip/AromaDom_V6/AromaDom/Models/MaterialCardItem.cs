﻿namespace AromaDom.Models
{
    public class MaterialCardItem
    {
        public int Id { get; set; }

        public int MaterialTypeId { get; set; }

        public string MaterialTypeName { get; set; } = string.Empty;

        public string Name { get; set; } = string.Empty;

        public decimal UnitPrice { get; set; }

        public double StockQuantity { get; set; }

        public double MinQuantity { get; set; }

        public double PackageQuantity { get; set; }

        public string Unit { get; set; } = string.Empty;

        public double RequiredQuantity { get; set; }
    }
}
