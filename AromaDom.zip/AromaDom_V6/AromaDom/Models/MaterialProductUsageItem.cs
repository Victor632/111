﻿namespace AromaDom.Models
{
    public class MaterialProductUsageItem
    {
        public string Article { get; set; } = string.Empty;

        public string ProductName { get; set; } = string.Empty;

        public string ProductTypeName { get; set; } = string.Empty;

        public double RequiredMaterialQuantity { get; set; }

        public string Unit { get; set; } = string.Empty;
    }
}
