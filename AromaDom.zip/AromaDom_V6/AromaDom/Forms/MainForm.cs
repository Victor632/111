﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Windows.Forms;
using AromaDom.Models;
using AromaDom.Services;

namespace AromaDom.Forms
{
    public class MainForm : Form
    {
        private readonly DatabaseService _databaseService;

        private readonly FlowLayoutPanel _cardsPanel;

        private readonly CultureInfo _ruCulture;

        public MainForm(DatabaseService databaseService)
        {
            _databaseService = databaseService;
            _ruCulture = new CultureInfo("ru-RU");

            Text = "Арома Дом — Список материалов";
            StartPosition = FormStartPosition.CenterScreen;
            MinimumSize = new Size(940, 640);
            Size = new Size(980, 720);
            BackColor = AppTheme.PrimaryBackground;
            Font = AppTheme.CreateFont(10f);
            AppTheme.ApplyWindowIcon(this);

            Panel headerPanel = BuildHeaderPanel();
            _cardsPanel = new FlowLayoutPanel();
            _cardsPanel.Dock = DockStyle.Fill;
            _cardsPanel.AutoScroll = true;
            _cardsPanel.FlowDirection = FlowDirection.TopDown;
            _cardsPanel.WrapContents = false;
            _cardsPanel.Padding = new Padding(20, 16, 20, 20);
            _cardsPanel.BackColor = AppTheme.PrimaryBackground;
            _cardsPanel.SizeChanged += OnCardsPanelSizeChanged;

            Controls.Add(_cardsPanel);
            Controls.Add(headerPanel);

            Load += OnMainFormLoad;
        }

        private Panel BuildHeaderPanel()
        {
            Panel header = new Panel();
            header.Size = new Size(960, 86);
            header.Dock = DockStyle.Top;
            header.BackColor = AppTheme.SecondaryBackground;
            header.Padding = new Padding(20, 12, 20, 12);

            PictureBox logoBox = new PictureBox();
            logoBox.Size = new Size(60, 60);
            logoBox.Location = new Point(20, 13);
            logoBox.SizeMode = PictureBoxSizeMode.Zoom;
            string logoPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Resources", "logo.png");
            if (File.Exists(logoPath))
            {
                logoBox.Image = Image.FromFile(logoPath);
            }

            Label titleLabel = new Label();
            titleLabel.Text = "Арома Дом — Учёт материалов";
            titleLabel.Font = AppTheme.CreateFont(16f, FontStyle.Bold);
            titleLabel.ForeColor = AppTheme.AccentColor;
            titleLabel.AutoSize = true;
            titleLabel.Location = new Point(94, 15);

            Label subtitleLabel = new Label();
            subtitleLabel.Text = "Нажмите на карточку для редактирования или откройте список продукции";
            subtitleLabel.Font = AppTheme.CreateFont(9.5f);
            subtitleLabel.ForeColor = AppTheme.TextColor;
            subtitleLabel.AutoSize = true;
            subtitleLabel.Location = new Point(96, 47);

            Panel rightButtonHost = new Panel();
            rightButtonHost.Dock = DockStyle.Right;
            rightButtonHost.Width = 220;
            rightButtonHost.BackColor = Color.Transparent;

            Button addButton = AppTheme.CreateAccentButton("+ Добавить материал", 210, 40);
            addButton.Location = new Point(5, 11);
            addButton.Click += OnAddMaterialClick;
            rightButtonHost.Controls.Add(addButton);

            header.Controls.Add(rightButtonHost);
            header.Controls.Add(logoBox);
            header.Controls.Add(titleLabel);
            header.Controls.Add(subtitleLabel);
            return header;
        }

        private void OnMainFormLoad(object? sender, EventArgs e)
        {
            RefreshMaterialCards();
        }

        private void OnCardsPanelSizeChanged(object? sender, EventArgs e)
        {
            int targetWidth = Math.Max(620, _cardsPanel.ClientSize.Width - 48);
            foreach (Control card in _cardsPanel.Controls)
            {
                card.Width = targetWidth;
            }
        }

        public void RefreshMaterialCards()
        {
            try
            {
                List<MaterialCardItem> materials = _databaseService.GetMaterialsWithRequiredQuantity();
                _cardsPanel.SuspendLayout();
                _cardsPanel.Controls.Clear();

                int cardWidth = Math.Max(620, _cardsPanel.ClientSize.Width - 48);
                foreach (MaterialCardItem item in materials)
                {
                    Panel card = CreateMaterialCard(item, cardWidth);
                    _cardsPanel.Controls.Add(card);
                }

                _cardsPanel.ResumeLayout();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    $"Не удалось загрузить список материалов из базы данных.
Техническая причина: {ex.Message}

" +
                    "Порядок исправления:
Проверьте наличие файла aroma_dom.db в каталоге программы и права доступа к нему.",
                    "Ошибка чтения базы данных",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private Panel CreateMaterialCard(MaterialCardItem item, int cardWidth)
        {
            Panel card = new Panel();
            card.Size = new Size(cardWidth, 130);
            card.Margin = new Padding(0, 0, 0, 12);
            card.BackColor = AppTheme.SecondaryBackground;
            card.BorderStyle = BorderStyle.FixedSingle;
            card.Cursor = Cursors.Hand;

            Label titleLabel = new Label();
            titleLabel.Text = $"{item.MaterialTypeName} | {item.Name}";
            titleLabel.Font = AppTheme.CreateFont(12f, FontStyle.Bold);
            titleLabel.ForeColor = AppTheme.TextColor;
            titleLabel.AutoSize = true;
            titleLabel.Location = new Point(16, 12);

            Label minQtyLabel = new Label();
            string minQtyFormatted = item.MinQuantity.ToString("0.##", _ruCulture);
            minQtyLabel.Text = $"Минимальное количество: {minQtyFormatted} {item.Unit}";
            minQtyLabel.Font = AppTheme.CreateFont(10f);
            minQtyLabel.ForeColor = AppTheme.TextColor;
            minQtyLabel.AutoSize = true;
            minQtyLabel.Location = new Point(16, 42);

            Label stockQtyLabel = new Label();
            string stockQtyFormatted = item.StockQuantity.ToString("0.##", _ruCulture);
            stockQtyLabel.Text = $"Количество на складе: {stockQtyFormatted} {item.Unit}";
            stockQtyLabel.Font = AppTheme.CreateFont(10f);
            stockQtyLabel.ForeColor = AppTheme.TextColor;
            stockQtyLabel.AutoSize = true;
            stockQtyLabel.Location = new Point(16, 66);

            Label priceLabel = new Label();
            string formattedPrice = item.UnitPrice.ToString("N2", _ruCulture);
            priceLabel.Text = $"Цена: {formattedPrice} р / Единица измерения: {item.Unit}";
            priceLabel.Font = AppTheme.CreateFont(10f);
            priceLabel.ForeColor = AppTheme.TextColor;
            priceLabel.AutoSize = true;
            priceLabel.Location = new Point(16, 92);

            Label requiredLabel = new Label();
            string formattedRequired = item.RequiredQuantity.ToString("F2", _ruCulture);
            requiredLabel.Text = $"Требуемое количество: {formattedRequired} {item.Unit}";
            requiredLabel.Font = AppTheme.CreateFont(11f, FontStyle.Bold);
            requiredLabel.ForeColor = AppTheme.AccentColor;
            requiredLabel.AutoSize = false;
            requiredLabel.Size = new Size(310, 26);
            requiredLabel.TextAlign = ContentAlignment.MiddleRight;
            requiredLabel.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            requiredLabel.Location = new Point(cardWidth - 328, 14);

            Button productsButton = AppTheme.CreateAccentButton("Продукция", 155, 34);
            productsButton.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            productsButton.Location = new Point(cardWidth - 173, 80);
            productsButton.Tag = item;
            productsButton.Click += OnProductsButtonClick;

            // Привязка обработчика клика ко всем текстовым элементам карточки для открытия формы редактирования
            int currentMaterialId = item.Id;
            EventHandler editHandler = (sender, args) => OpenEditWindow(currentMaterialId);
            card.Click += editHandler;
            titleLabel.Click += editHandler;
            minQtyLabel.Click += editHandler;
            stockQtyLabel.Click += editHandler;
            priceLabel.Click += editHandler;
            requiredLabel.Click += editHandler;

            card.Controls.Add(titleLabel);
            card.Controls.Add(minQtyLabel);
            card.Controls.Add(stockQtyLabel);
            card.Controls.Add(priceLabel);
            card.Controls.Add(requiredLabel);
            card.Controls.Add(productsButton);
            return card;
        }

        private void OnProductsButtonClick(object? sender, EventArgs e)
        {
            if (sender is Button button && button.Tag is MaterialCardItem selectedMaterial)
            {
                OpenProductsWindow(selectedMaterial);
            }
        }

        private void OnAddMaterialClick(object? sender, EventArgs e)
        {
            using MaterialEditForm addForm = new MaterialEditForm(_databaseService, null);
            Hide();
            DialogResult result = addForm.ShowDialog(this);
            Show();
            if (result == DialogResult.OK)
            {
                RefreshMaterialCards();
            }
        }

        private void OpenEditWindow(int materialId)
        {
            using MaterialEditForm editForm = new MaterialEditForm(_databaseService, materialId);
            Hide();
            DialogResult result = editForm.ShowDialog(this);
            Show();
            if (result == DialogResult.OK)
            {
                RefreshMaterialCards();
            }
        }

        private void OpenProductsWindow(MaterialCardItem material)
        {
            using MaterialProductsForm productsForm = new MaterialProductsForm(_databaseService, material);
            Hide();
            productsForm.ShowDialog(this);
            Show();
        }
    }
}
