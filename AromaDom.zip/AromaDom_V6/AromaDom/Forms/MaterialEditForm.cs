﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Windows.Forms;
using AromaDom.Models;
using AromaDom.Services;
using Microsoft.Data.Sqlite;

namespace AromaDom.Forms
{
    public class MaterialEditForm : Form
    {
        private readonly DatabaseService _databaseService;

        private readonly int? _editingMaterialId;

        private readonly ComboBox _typeComboBox;

        private readonly TextBox _nameTextBox;

        private readonly TextBox _priceTextBox;

        private readonly TextBox _unitTextBox;

        private readonly TextBox _packageQtyTextBox;

        private readonly TextBox _stockQtyTextBox;

        private readonly TextBox _minQtyTextBox;

        private bool _hasUnsavedChanges;

        public MaterialEditForm(DatabaseService databaseService, int? materialId)
        {
            _databaseService = databaseService;
            _editingMaterialId = materialId;

            bool isEdit = materialId.HasValue;
            Text = isEdit
                ? "Арома Дом — Редактирование материала"
                : "Арома Дом — Добавление материала";

            StartPosition = FormStartPosition.CenterParent;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            Size = new Size(630, 625);
            BackColor = AppTheme.PrimaryBackground;
            Font = AppTheme.CreateFont(10f);
            AppTheme.ApplyWindowIcon(this);

            Panel headerPanel = new Panel();
            headerPanel.Dock = DockStyle.Top;
            headerPanel.Height = 64;
            headerPanel.BackColor = AppTheme.SecondaryBackground;

            Label headerLabel = new Label();
            headerLabel.Text = Text;
            headerLabel.Font = AppTheme.CreateFont(14f, FontStyle.Bold);
            headerLabel.ForeColor = AppTheme.AccentColor;
            headerLabel.AutoSize = true;
            headerLabel.Location = new Point(22, 18);
            headerPanel.Controls.Add(headerLabel);

            _typeComboBox = new ComboBox();
            _typeComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
            _typeComboBox.Font = AppTheme.CreateFont(10f);
            _typeComboBox.Width = 340;

            _nameTextBox = CreateInputBox();
            _priceTextBox = CreateInputBox();
            _unitTextBox = CreateInputBox();
            _packageQtyTextBox = CreateInputBox();
            _stockQtyTextBox = CreateInputBox();
            _minQtyTextBox = CreateInputBox();

            Panel bodyPanel = new Panel();
            bodyPanel.Dock = DockStyle.Fill;
            bodyPanel.Padding = new Padding(24, 16, 24, 16);

            AddFieldRow(bodyPanel, 15, "Тип материала:", _typeComboBox, "Выберите категорию материала из списка");
            AddFieldRow(bodyPanel, 75, "Наименование:", _nameTextBox, "Введите уникальное наименование материала");
            AddFieldRow(bodyPanel, 135, "Цена единицы (р):", _priceTextBox, "Неотрицательное число до сотых (пример: 890,00)");
            AddFieldRow(bodyPanel, 195, "Единица измерения:", _unitTextBox, "Укажите единицу измерения: кг, л, шт или м");
            AddFieldRow(bodyPanel, 255, "Количество в упаковке:", _packageQtyTextBox, "Положительное число больше нуля");
            AddFieldRow(bodyPanel, 315, "Количество на складе:", _stockQtyTextBox, "Текущий остаток материала на складе (>= 0)");
            AddFieldRow(bodyPanel, 375, "Минимальное количество:", _minQtyTextBox, "Минимально допустимый запас (>= 0)");

            Button backButton = AppTheme.CreateSecondaryButton("← Назад", 140, 40);
            backButton.Location = new Point(24, 455);
            backButton.Click += OnBackButtonClick;

            Button saveButton = AppTheme.CreateAccentButton("Сохранить", 190, 40);
            saveButton.Location = new Point(380, 455);
            saveButton.Click += OnSaveButtonClick;

            bodyPanel.Controls.Add(backButton);
            bodyPanel.Controls.Add(saveButton);

            Controls.Add(bodyPanel);
            Controls.Add(headerPanel);

            Load += OnFormLoad;
        }

        private TextBox CreateInputBox()
        {
            TextBox box = new TextBox();
            box.Width = 340;
            box.Font = AppTheme.CreateFont(10f);
            box.TextChanged += OnInputChanged;
            return box;
        }

        private void OnInputChanged(object? sender, EventArgs e)
        {
            _hasUnsavedChanges = true;
        }

        private static void AddFieldRow(Panel parent, int top, string labelText, Control editor, string hintText)
        {
            Label label = new Label();
            label.Text = labelText;
            label.Font = AppTheme.CreateFont(10f, FontStyle.Bold);
            label.ForeColor = AppTheme.TextColor;
            label.Location = new Point(24, top + 4);
            label.Size = new Size(200, 24);

            editor.Location = new Point(230, top);

            Label hint = new Label();
            hint.Text = hintText;
            hint.Font = AppTheme.CreateFont(8.2f, FontStyle.Italic);
            hint.ForeColor = Color.DimGray;
            hint.Location = new Point(230, top + 28);
            hint.Size = new Size(355, 18);

            parent.Controls.Add(label);
            parent.Controls.Add(editor);
            parent.Controls.Add(hint);
        }

        private void OnFormLoad(object? sender, EventArgs e)
        {
            try
            {
                List<MaterialTypeItem> types = _databaseService.GetMaterialTypes();
                _typeComboBox.DataSource = types;
                _typeComboBox.DisplayMember = "Name";
                _typeComboBox.ValueMember = "Id";

                if (_editingMaterialId.HasValue)
                {
                    MaterialCardItem? existing = _databaseService.GetMaterialById(_editingMaterialId.Value);
                    if (existing == null)
                    {
                        MessageBox.Show(
                            "Выбранный материал не найден в базе данных. Возможно, запись была удалена.",
                            "Предупреждение",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);
                        DialogResult = DialogResult.Cancel;
                        Close();
                        return;
                    }

                    CultureInfo ru = new CultureInfo("ru-RU");
                    _typeComboBox.SelectedValue = existing.MaterialTypeId;
                    _nameTextBox.Text = existing.Name;
                    _priceTextBox.Text = existing.UnitPrice.ToString("F2", ru);
                    _unitTextBox.Text = existing.Unit;
                    _packageQtyTextBox.Text = existing.PackageQuantity.ToString("0.###", ru);
                    _stockQtyTextBox.Text = existing.StockQuantity.ToString("0.###", ru);
                    _minQtyTextBox.Text = existing.MinQuantity.ToString("0.###", ru);
                }

                _hasUnsavedChanges = false;
                _typeComboBox.SelectedIndexChanged += OnInputChanged;
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    $"Ошибка при загрузке данных материала: {ex.Message}

" +
                    "Порядок исправления:
Вернитесь к списку материалов кнопкой «Назад» и проверьте целостность БД.",
                    "Ошибка загрузки данных",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void OnBackButtonClick(object? sender, EventArgs e)
        {
            if (_hasUnsavedChanges)
            {
                DialogResult confirm = MessageBox.Show(
                    "В форме имеются несохранённые изменения. При возврате назад введённые данные будут потеряны.

" +
                    "Продолжить выход без сохранения?",
                    "Предупреждение о неотвратимой операции",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Warning);

                if (confirm != DialogResult.Yes)
                {
                    return;
                }
            }

            DialogResult = DialogResult.Cancel;
            Close();
        }

        private void OnSaveButtonClick(object? sender, EventArgs e)
        {
            if (_typeComboBox.SelectedItem is not MaterialTypeItem selectedType)
            {
                ShowValidationError("Не выбран тип материала.", "Выберите тип материала из выпадающего списка.");
                return;
            }

            string materialName = _nameTextBox.Text.Trim();
            if (string.IsNullOrWhiteSpace(materialName))
            {
                ShowValidationError("Поле «Наименование» не заполнено.", "Введите наименование материала.");
                _nameTextBox.Focus();
                return;
            }

            if (!TryParsePrice(_priceTextBox.Text, out decimal unitPrice, out string priceError))
            {
                ShowValidationError(
                    priceError,
                    "Введите неотрицательную цену с точностью не более двух знаков после запятой (например: 450,00).");
                _priceTextBox.Focus();
                return;
            }

            string unit = _unitTextBox.Text.Trim();
            if (string.IsNullOrWhiteSpace(unit))
            {
                ShowValidationError("Поле «Единица измерения» не заполнено.", "Укажите единицу измерения (кг, л, шт, м).");
                _unitTextBox.Focus();
                return;
            }

            if (!TryParseDouble(_packageQtyTextBox.Text, out double packageQty) || packageQty <= 0.0)
            {
                ShowValidationError(
                    "Некорректное значение в поле «Количество в упаковке».",
                    "Введите положительное число больше нуля (например: 20).");
                _packageQtyTextBox.Focus();
                return;
            }

            if (!TryParseDouble(_stockQtyTextBox.Text, out double stockQty) || stockQty < 0.0)
            {
                ShowValidationError(
                    "Некорректное значение в поле «Количество на складе».",
                    "Введите неотрицательное число (0 или больше).");
                _stockQtyTextBox.Focus();
                return;
            }

            if (!TryParseDouble(_minQtyTextBox.Text, out double minQty) || minQty < 0.0)
            {
                ShowValidationError(
                    "Поле «Минимальное количество» не может принимать отрицательные значения.",
                    "Введите неотрицательное число (0 или больше).");
                _minQtyTextBox.Focus();
                return;
            }

            try
            {
                MaterialCardItem model = new MaterialCardItem();
                model.Id = _editingMaterialId ?? 0;
                model.MaterialTypeId = selectedType.Id;
                model.Name = materialName;
                model.UnitPrice = unitPrice;
                model.Unit = unit;
                model.PackageQuantity = packageQty;
                model.StockQuantity = stockQty;
                model.MinQuantity = minQty;

                _databaseService.SaveMaterial(model, _editingMaterialId.HasValue);

                MessageBox.Show(
                    "Данные о материале успешно сохранены в базе данных.",
                    "Информация",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                _hasUnsavedChanges = false;
                DialogResult = DialogResult.OK;
                Close();
            }
            catch (SqliteException sqlEx) when (sqlEx.SqliteErrorCode == 19)
            {
                ShowValidationError(
                    $"Материал с наименованием «{materialName}» уже зарегистрирован в системе.",
                    "Укажите уникальное наименование материала или отредактируйте существующую карточку.");
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    $"Не удалось сохранить данные материала.
Техническая деталь: {ex.Message}

" +
                    "Порядок исправления:
Проверьте доступность файла базы данных и повторите сохранение.",
                    "Ошибка сохранения",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private static bool TryParsePrice(string rawText, out decimal price, out string errorMessage)
        {
            price = 0m;
            errorMessage = string.Empty;
            string normalized = rawText.Trim().Replace(',', '.');

            if (!decimal.TryParse(normalized, NumberStyles.Number, CultureInfo.InvariantCulture, out price))
            {
                errorMessage = "В поле «Цена единицы материала» введено некорректное числовое значение.";
                return false;
            }

            if (price < 0m)
            {
                errorMessage = "Цена единицы материала не может быть отрицательной.";
                return false;
            }

            // Проверка ограничения точности цены: не более двух десятичных разрядов
            if (decimal.Round(price, 2) != price)
            {
                errorMessage = "Цена единицы материала должна быть указана с точностью до сотых.";
                return false;
            }

            return true;
        }

        private static bool TryParseDouble(string rawText, out double result)
        {
            string normalized = rawText.Trim().Replace(',', '.');
            return double.TryParse(normalized, NumberStyles.Float, CultureInfo.InvariantCulture, out result);
        }

        private static void ShowValidationError(string problemDescription, string fixInstructions)
        {
            MessageBox.Show(
                $"{problemDescription}

Порядок исправления:
{fixInstructions}",
                "Ошибка ввода данных",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);
        }
    }
}
