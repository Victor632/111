﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Windows.Forms;
using AromaDom.Models;
using AromaDom.Services;

namespace AromaDom.Forms
{
    public class MaterialProductsForm : Form
    {
        private readonly DatabaseService _databaseService;

        private readonly MaterialCardItem _material;

        private readonly DataGridView _productsGrid;

        private readonly Label _summaryLabel;

        public MaterialProductsForm(DatabaseService databaseService, MaterialCardItem material)
        {
            _databaseService = databaseService;
            _material = material;

            Text = $"Арома Дом — Продукция с материалом «{material.Name}»";
            StartPosition = FormStartPosition.CenterParent;
            MinimumSize = new Size(780, 520);
            Size = new Size(850, 560);
            BackColor = AppTheme.PrimaryBackground;
            Font = AppTheme.CreateFont(10f);
            AppTheme.ApplyWindowIcon(this);

            Panel headerPanel = new Panel();
            headerPanel.Dock = DockStyle.Top;
            headerPanel.Height = 76;
            headerPanel.BackColor = AppTheme.SecondaryBackground;

            Label titleLabel = new Label();
            titleLabel.Text = $"Продукция, в производстве которой используется: {material.Name}";
            titleLabel.Font = AppTheme.CreateFont(13f, FontStyle.Bold);
            titleLabel.ForeColor = AppTheme.AccentColor;
            titleLabel.AutoSize = true;
            titleLabel.Location = new Point(20, 14);

            _summaryLabel = new Label();
            _summaryLabel.Font = AppTheme.CreateFont(10f);
            _summaryLabel.ForeColor = AppTheme.TextColor;
            _summaryLabel.AutoSize = true;
            _summaryLabel.Location = new Point(20, 44);

            headerPanel.Controls.Add(titleLabel);
            headerPanel.Controls.Add(_summaryLabel);

            Panel footerPanel = new Panel();
            footerPanel.Dock = DockStyle.Bottom;
            footerPanel.Height = 64;
            footerPanel.BackColor = AppTheme.SecondaryBackground;

            Button backButton = AppTheme.CreateSecondaryButton("← Назад к списку", 210, 38);
            backButton.Location = new Point(20, 13);
            backButton.Click += OnBackButtonClick;
            footerPanel.Controls.Add(backButton);

            _productsGrid = BuildProductsGrid(material.Unit);

            Controls.Add(_productsGrid);
            Controls.Add(footerPanel);
            Controls.Add(headerPanel);

            Load += OnProductsFormLoad;
        }

        private static DataGridView BuildProductsGrid(string unit)
        {
            DataGridView grid = new DataGridView();
            grid.Dock = DockStyle.Fill;
            grid.BackgroundColor = AppTheme.PrimaryBackground;
            grid.BorderStyle = BorderStyle.None;
            grid.ReadOnly = true;
            grid.AllowUserToAddRows = false;
            grid.AllowUserToDeleteRows = false;
            grid.RowHeadersVisible = false;
            grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            grid.EnableHeadersVisualStyles = false;
            grid.ColumnHeadersDefaultCellStyle.BackColor = AppTheme.AccentColor;
            grid.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            grid.ColumnHeadersDefaultCellStyle.Font = AppTheme.CreateFont(10f, FontStyle.Bold);
            grid.ColumnHeadersHeight = 38;
            grid.DefaultCellStyle.Font = AppTheme.CreateFont(10f);
            grid.RowTemplate.Height = 32;

            DataGridViewTextBoxColumn articleCol = new DataGridViewTextBoxColumn();
            articleCol.Name = "Article";
            articleCol.HeaderText = "Артикул";
            articleCol.FillWeight = 16f;

            DataGridViewTextBoxColumn nameCol = new DataGridViewTextBoxColumn();
            nameCol.Name = "ProductName";
            nameCol.HeaderText = "Наименование продукции";
            nameCol.FillWeight = 44f;

            DataGridViewTextBoxColumn typeCol = new DataGridViewTextBoxColumn();
            typeCol.Name = "ProductType";
            typeCol.HeaderText = "Тип продукции";
            typeCol.FillWeight = 20f;

            DataGridViewTextBoxColumn qtyCol = new DataGridViewTextBoxColumn();
            qtyCol.Name = "MaterialQty";
            qtyCol.HeaderText = $"Необходимое количество ({unit})";
            qtyCol.FillWeight = 20f;

            grid.Columns.Add(articleCol);
            grid.Columns.Add(nameCol);
            grid.Columns.Add(typeCol);
            grid.Columns.Add(qtyCol);
            return grid;
        }

        private void OnBackButtonClick(object? sender, EventArgs e)
        {
            Close();
        }

        private void OnProductsFormLoad(object? sender, EventArgs e)
        {
            try
            {
                List<MaterialProductUsageItem> rows = _databaseService.GetProductsByMaterialId(_material.Id);
                CultureInfo ru = new CultureInfo("ru-RU");
                _productsGrid.Rows.Clear();

                double totalUsed = 0.0;
                foreach (MaterialProductUsageItem item in rows)
                {
                    totalUsed += item.RequiredMaterialQuantity;
                    _productsGrid.Rows.Add(
                        item.Article,
                        item.ProductName,
                        item.ProductTypeName,
                        item.RequiredMaterialQuantity.ToString("0.###", ru));
                }

                string formattedTotal = Math.Round(totalUsed, 2).ToString("F2", ru);
                _summaryLabel.Text =
                    $"Позиций продукции: {rows.Count} | " +
                    $"Суммарное требуемое количество материала: {formattedTotal} {_material.Unit}";

                if (rows.Count == 0)
                {
                    MessageBox.Show(
                        $"Материал «{_material.Name}» в настоящий момент не используется ни в одной рецептуре продукции.",
                        "Информация",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    $"Ошибка при загрузке списка продукции: {ex.Message}

" +
                    "Порядок исправления:
Нажмите «Назад к списку» и проверьте доступность базы данных.",
                    "Ошибка чтения данных",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }
    }
}
