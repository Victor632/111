﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using AromaDom.Models;
using Microsoft.Data.Sqlite;

namespace AromaDom.Services
{
    public class DatabaseService
    {
        private readonly string _databaseFilePath;

        private readonly string _connectionString;

        public DatabaseService(string? customDatabasePath = null)
        {
            string defaultPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "aroma_dom.db");
            _databaseFilePath = customDatabasePath ?? defaultPath;
            _connectionString = $"Data Source={_databaseFilePath};Foreign Keys=True;";
        }

        public string ConnectionString
        {
            get
            {
                return _connectionString;
            }
        }

        public void EnsureDatabaseInitialized()
        {
            if (File.Exists(_databaseFilePath))
            {
                return;
            }

            string scriptPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "db_script.sql");
            if (!File.Exists(scriptPath))
            {
                throw new FileNotFoundException(
                    "Не найден файл базы данных aroma_dom.db и SQL-скрипт db_script.sql. " +
                    "Поместите файл aroma_dom.db или db_script.sql в каталог приложения.");
            }

            string sqlScript = File.ReadAllText(scriptPath);
            using SqliteConnection connection = new SqliteConnection(_connectionString);
            connection.Open();
            using SqliteCommand command = connection.CreateCommand();
            command.CommandText = sqlScript;
            command.ExecuteNonQuery();
        }

        public List<MaterialTypeItem> GetMaterialTypes()
        {
            List<MaterialTypeItem> items = new List<MaterialTypeItem>();
            using SqliteConnection connection = new SqliteConnection(_connectionString);
            connection.Open();

            using SqliteCommand command = connection.CreateCommand();
            command.CommandText = "SELECT id, name, loss_percent FROM material_types ORDER BY name;";

            using SqliteDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                MaterialTypeItem item = new MaterialTypeItem();
                item.Id = reader.GetInt32(0);
                item.Name = reader.GetString(1);
                item.LossPercent = reader.GetDouble(2);
                items.Add(item);
            }

            return items;
        }

        public List<MaterialCardItem> GetMaterialsWithRequiredQuantity()
        {
            List<MaterialCardItem> materials = new List<MaterialCardItem>();
            using SqliteConnection connection = new SqliteConnection(_connectionString);
            connection.Open();

            // LEFT JOIN сохраняет в выборке материалы, ещё не включённые ни в одну рецептуру продукции
            string query = @"
                SELECT
                    m.id,
                    m.material_type_id,
                    mt.name AS type_name,
                    m.name,
                    m.unit_price,
                    m.stock_quantity,
                    m.min_quantity,
                    m.package_quantity,
                    m.unit,
                    ROUND(COALESCE(SUM(mp.material_quantity), 0.0), 2) AS required_quantity
                FROM materials m
                INNER JOIN material_types mt ON mt.id = m.material_type_id
                LEFT JOIN material_products mp ON mp.material_id = m.id
                GROUP BY
                    m.id,
                    m.material_type_id,
                    mt.name,
                    m.name,
                    m.unit_price,
                    m.stock_quantity,
                    m.min_quantity,
                    m.package_quantity,
                    m.unit
                ORDER BY m.name;";

            using SqliteCommand command = connection.CreateCommand();
            command.CommandText = query;

            using SqliteDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                MaterialCardItem item = new MaterialCardItem();
                item.Id = reader.GetInt32(0);
                item.MaterialTypeId = reader.GetInt32(1);
                item.MaterialTypeName = reader.GetString(2);
                item.Name = reader.GetString(3);
                item.UnitPrice = Convert.ToDecimal(reader.GetDouble(4), CultureInfo.InvariantCulture);
                item.StockQuantity = reader.GetDouble(5);
                item.MinQuantity = reader.GetDouble(6);
                item.PackageQuantity = reader.GetDouble(7);
                item.Unit = reader.GetString(8);
                item.RequiredQuantity = reader.GetDouble(9);
                materials.Add(item);
            }

            return materials;
        }

        public MaterialCardItem? GetMaterialById(int materialId)
        {
            using SqliteConnection connection = new SqliteConnection(_connectionString);
            connection.Open();

            string query = @"
                SELECT
                    m.id,
                    m.material_type_id,
                    mt.name,
                    m.name,
                    m.unit_price,
                    m.stock_quantity,
                    m.min_quantity,
                    m.package_quantity,
                    m.unit
                FROM materials m
                INNER JOIN material_types mt ON mt.id = m.material_type_id
                WHERE m.id = @id;";

            using SqliteCommand command = connection.CreateCommand();
            command.CommandText = query;
            command.Parameters.AddWithValue("@id", materialId);

            using SqliteDataReader reader = command.ExecuteReader();
            if (!reader.Read())
            {
                return null;
            }

            MaterialCardItem item = new MaterialCardItem();
            item.Id = reader.GetInt32(0);
            item.MaterialTypeId = reader.GetInt32(1);
            item.MaterialTypeName = reader.GetString(2);
            item.Name = reader.GetString(3);
            item.UnitPrice = Convert.ToDecimal(reader.GetDouble(4), CultureInfo.InvariantCulture);
            item.StockQuantity = reader.GetDouble(5);
            item.MinQuantity = reader.GetDouble(6);
            item.PackageQuantity = reader.GetDouble(7);
            item.Unit = reader.GetString(8);
            return item;
        }

        public void SaveMaterial(MaterialCardItem material, bool isEditMode)
        {
            using SqliteConnection connection = new SqliteConnection(_connectionString);
            connection.Open();

            using SqliteCommand command = connection.CreateCommand();
            if (isEditMode)
            {
                command.CommandText = @"
                    UPDATE materials
                    SET name = @name,
                        material_type_id = @typeId,
                        unit_price = @price,
                        stock_quantity = @stock,
                        min_quantity = @minQty,
                        package_quantity = @pkgQty,
                        unit = @unit
                    WHERE id = @id;";
                command.Parameters.AddWithValue("@id", material.Id);
            }
            else
            {
                command.CommandText = @"
                    INSERT INTO materials
                        (name, material_type_id, unit_price, stock_quantity, min_quantity, package_quantity, unit)
                    VALUES
                        (@name, @typeId, @price, @stock, @minQty, @pkgQty, @unit);";
            }

            command.Parameters.AddWithValue("@name", material.Name.Trim());
            command.Parameters.AddWithValue("@typeId", material.MaterialTypeId);
            command.Parameters.AddWithValue("@price", (double)Math.Round(material.UnitPrice, 2));
            command.Parameters.AddWithValue("@stock", material.StockQuantity);
            command.Parameters.AddWithValue("@minQty", material.MinQuantity);
            command.Parameters.AddWithValue("@pkgQty", material.PackageQuantity);
            command.Parameters.AddWithValue("@unit", material.Unit.Trim());
            command.ExecuteNonQuery();
        }

        public List<MaterialProductUsageItem> GetProductsByMaterialId(int materialId)
        {
            List<MaterialProductUsageItem> usageList = new List<MaterialProductUsageItem>();
            using SqliteConnection connection = new SqliteConnection(_connectionString);
            connection.Open();

            string query = @"
                SELECT
                    p.article,
                    p.name,
                    pt.name AS product_type_name,
                    mp.material_quantity,
                    m.unit
                FROM material_products mp
                INNER JOIN products p ON p.id = mp.product_id
                INNER JOIN product_types pt ON pt.id = p.product_type_id
                INNER JOIN materials m ON m.id = mp.material_id
                WHERE mp.material_id = @materialId
                ORDER BY p.name;";

            using SqliteCommand command = connection.CreateCommand();
            command.CommandText = query;
            command.Parameters.AddWithValue("@materialId", materialId);

            using SqliteDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                MaterialProductUsageItem row = new MaterialProductUsageItem();
                row.Article = reader.GetString(0);
                row.ProductName = reader.GetString(1);
                row.ProductTypeName = reader.GetString(2);
                row.RequiredMaterialQuantity = reader.GetDouble(3);
                row.Unit = reader.GetString(4);
                usageList.Add(row);
            }

            return usageList;
        }
    }
}
