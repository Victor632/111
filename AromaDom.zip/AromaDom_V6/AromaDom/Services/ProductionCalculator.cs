﻿using System;
using Microsoft.Data.Sqlite;

namespace AromaDom.Services
{
    public class ProductionCalculator
    {
        private readonly string _connectionString;

        public ProductionCalculator(string connectionString)
        {
            _connectionString = connectionString;
        }

        public int CalculateProductQuantity(
            int productTypeId,
            int materialTypeId,
            int rawMaterialAmount,
            double productParam1,
            double productParam2)
        {
            if (productTypeId <= 0 || materialTypeId <= 0 || rawMaterialAmount <= 0)
            {
                return -1;
            }

            if (double.IsNaN(productParam1) || double.IsInfinity(productParam1) || productParam1 <= 0.0)
            {
                return -1;
            }

            if (double.IsNaN(productParam2) || double.IsInfinity(productParam2) || productParam2 <= 0.0)
            {
                return -1;
            }

            try
            {
                using SqliteConnection connection = new SqliteConnection(_connectionString);
                connection.Open();

                double? productCoefficient = GetScalarDouble(
                    connection,
                    "SELECT coefficient FROM product_types WHERE id = @id;",
                    productTypeId);

                double? materialLossPercent = GetScalarDouble(
                    connection,
                    "SELECT loss_percent FROM material_types WHERE id = @id;",
                    materialTypeId);

                if (!productCoefficient.HasValue || !materialLossPercent.HasValue)
                {
                    return -1;
                }

                if (productCoefficient.Value <= 0.0 || materialLossPercent.Value < 0.0)
                {
                    return -1;
                }

                // Норма расхода сырья на единицу продукции увеличивается на процент технологических потерь
                double baseMaterialPerUnit = productParam1 * productParam2 * productCoefficient.Value;
                double lossFactor = 1.0 + (materialLossPercent.Value / 100.0);
                double totalMaterialPerUnit = baseMaterialPerUnit * lossFactor;

                if (totalMaterialPerUnit <= 0.0)
                {
                    return -1;
                }

                double productCount = Math.Floor(rawMaterialAmount / totalMaterialPerUnit);
                if (productCount > int.MaxValue)
                {
                    return -1;
                }

                return (int)productCount;
            }
            catch (SqliteException)
            {
                return -1;
            }
        }

        private static double? GetScalarDouble(SqliteConnection connection, string sql, int entityId)
        {
            using SqliteCommand command = connection.CreateCommand();
            command.CommandText = sql;
            command.Parameters.AddWithValue("@id", entityId);
            object? result = command.ExecuteScalar();
            if (result == null || result == DBNull.Value)
            {
                return null;
            }

            return Convert.ToDouble(result);
        }
    }
}
