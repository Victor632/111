-- База данных подсистемы учёта материалов компании «Арома Дом» (PostgreSQL 14+)
DROP TABLE IF EXISTS material_products CASCADE;
DROP TABLE IF EXISTS materials CASCADE;
DROP TABLE IF EXISTS products CASCADE;
DROP TABLE IF EXISTS material_types CASCADE;
DROP TABLE IF EXISTS product_types CASCADE;

CREATE TABLE material_types (
    id SERIAL PRIMARY KEY,
    name VARCHAR(150) NOT NULL UNIQUE,
    loss_percent NUMERIC(6, 4) NOT NULL CHECK (loss_percent >= 0 AND loss_percent < 100)
);
CREATE TABLE product_types (
    id SERIAL PRIMARY KEY,
    name VARCHAR(150) NOT NULL UNIQUE,
    coefficient NUMERIC(8, 4) NOT NULL CHECK (coefficient > 0)
);
CREATE TABLE materials (
    id SERIAL PRIMARY KEY,
    name VARCHAR(200) NOT NULL UNIQUE,
    material_type_id INTEGER NOT NULL REFERENCES material_types(id) ON UPDATE CASCADE ON DELETE RESTRICT,
    unit_price NUMERIC(12, 2) NOT NULL CHECK (unit_price >= 0),
    stock_quantity NUMERIC(12, 3) NOT NULL CHECK (stock_quantity >= 0),
    min_quantity NUMERIC(12, 3) NOT NULL CHECK (min_quantity >= 0),
    package_quantity NUMERIC(12, 3) NOT NULL CHECK (package_quantity > 0),
    unit VARCHAR(30) NOT NULL
);
CREATE TABLE products (
    id SERIAL PRIMARY KEY,
    article VARCHAR(50) NOT NULL UNIQUE,
    product_type_id INTEGER NOT NULL REFERENCES product_types(id) ON UPDATE CASCADE ON DELETE RESTRICT,
    name VARCHAR(200) NOT NULL UNIQUE,
    min_partner_price NUMERIC(12, 2) NOT NULL CHECK (min_partner_price >= 0)
);
CREATE TABLE material_products (
    id SERIAL PRIMARY KEY,
    material_id INTEGER NOT NULL REFERENCES materials(id) ON UPDATE CASCADE ON DELETE CASCADE,
    product_id INTEGER NOT NULL REFERENCES products(id) ON UPDATE CASCADE ON DELETE CASCADE,
    material_quantity NUMERIC(12, 4) NOT NULL CHECK (material_quantity > 0),
    UNIQUE (material_id, product_id)
);

-- 1. Импорт типов материалов
INSERT INTO material_types (id, name, loss_percent) VALUES (1, 'Соевый воск', 0.12);
INSERT INTO material_types (id, name, loss_percent) VALUES (2, 'Пчелиный воск', 0.18);
INSERT INTO material_types (id, name, loss_percent) VALUES (3, 'Ароматическое масло', 0.25);
INSERT INTO material_types (id, name, loss_percent) VALUES (4, 'Краситель', 0.08);
INSERT INTO material_types (id, name, loss_percent) VALUES (5, 'Фитиль', 0.03);
INSERT INTO material_types (id, name, loss_percent) VALUES (6, 'Стеклянная тара', 0.04);
INSERT INTO material_types (id, name, loss_percent) VALUES (7, 'Керамическая тара', 0.06);
INSERT INTO material_types (id, name, loss_percent) VALUES (8, 'Декор', 0.1);
INSERT INTO material_types (id, name, loss_percent) VALUES (9, 'Упаковка', 0.05);
INSERT INTO material_types (id, name, loss_percent) VALUES (10, 'Этикетка', 0.02);

-- 2. Импорт типов продукции
INSERT INTO product_types (id, name, coefficient) VALUES (1, 'Классическая свеча', 1.00);
INSERT INTO product_types (id, name, coefficient) VALUES (2, 'Премиальная свеча', 1.15);
INSERT INTO product_types (id, name, coefficient) VALUES (3, 'Подарочный набор', 1.30);
INSERT INTO product_types (id, name, coefficient) VALUES (4, 'Интерьерная свеча', 1.20);
INSERT INTO product_types (id, name, coefficient) VALUES (5, 'Мини-свеча', 0.80);
INSERT INTO product_types (id, name, coefficient) VALUES (6, 'Сезонная коллекция', 1.25);

-- 3. Импорт материалов
INSERT INTO materials (id, name, material_type_id, unit_price, stock_quantity, min_quantity, package_quantity, unit) VALUES (1, 'Соевый воск премиум', 1, 890.00, 120.0, 40.0, 20.0, 'кг');
INSERT INTO materials (id, name, material_type_id, unit_price, stock_quantity, min_quantity, package_quantity, unit) VALUES (2, 'Соевый воск EcoBlend', 1, 760.00, 95.0, 30.0, 25.0, 'кг');
INSERT INTO materials (id, name, material_type_id, unit_price, stock_quantity, min_quantity, package_quantity, unit) VALUES (3, 'Пчелиный воск натуральный', 2, 1450.00, 48.0, 15.0, 10.0, 'кг');
INSERT INTO materials (id, name, material_type_id, unit_price, stock_quantity, min_quantity, package_quantity, unit) VALUES (4, 'Масло лаванды', 3, 3200.00, 18.5, 6.0, 1.0, 'л');
INSERT INTO materials (id, name, material_type_id, unit_price, stock_quantity, min_quantity, package_quantity, unit) VALUES (5, 'Масло ванили', 3, 2950.00, 22.0, 8.0, 1.0, 'л');
INSERT INTO materials (id, name, material_type_id, unit_price, stock_quantity, min_quantity, package_quantity, unit) VALUES (6, 'Масло цитрусовое', 3, 2870.00, 16.7, 5.0, 1.0, 'л');
INSERT INTO materials (id, name, material_type_id, unit_price, stock_quantity, min_quantity, package_quantity, unit) VALUES (7, 'Краситель янтарный', 4, 640.00, 6.2, 2.0, 0.5, 'кг');
INSERT INTO materials (id, name, material_type_id, unit_price, stock_quantity, min_quantity, package_quantity, unit) VALUES (8, 'Краситель розовый', 4, 615.00, 5.1, 1.5, 0.5, 'кг');
INSERT INTO materials (id, name, material_type_id, unit_price, stock_quantity, min_quantity, package_quantity, unit) VALUES (9, 'Фитиль хлопковый 8 см', 5, 4.50, 2500.0, 800.0, 500.0, 'шт');
INSERT INTO materials (id, name, material_type_id, unit_price, stock_quantity, min_quantity, package_quantity, unit) VALUES (10, 'Фитиль хлопковый 12 см', 5, 5.80, 1800.0, 600.0, 400.0, 'шт');
INSERT INTO materials (id, name, material_type_id, unit_price, stock_quantity, min_quantity, package_quantity, unit) VALUES (11, 'Стакан прозрачный 200 мл', 6, 28.00, 950.0, 300.0, 100.0, 'шт');
INSERT INTO materials (id, name, material_type_id, unit_price, stock_quantity, min_quantity, package_quantity, unit) VALUES (12, 'Стакан матовый 250 мл', 6, 34.00, 620.0, 200.0, 60.0, 'шт');
INSERT INTO materials (id, name, material_type_id, unit_price, stock_quantity, min_quantity, package_quantity, unit) VALUES (13, 'Чаша керамическая белая', 7, 72.00, 280.0, 80.0, 40.0, 'шт');
INSERT INTO materials (id, name, material_type_id, unit_price, stock_quantity, min_quantity, package_quantity, unit) VALUES (14, 'Сухоцветы лаванды', 8, 520.00, 4.8, 1.5, 0.3, 'кг');
INSERT INTO materials (id, name, material_type_id, unit_price, stock_quantity, min_quantity, package_quantity, unit) VALUES (15, 'Лента сатиновая бежевая', 9, 12.00, 340.0, 120.0, 50.0, 'м');
INSERT INTO materials (id, name, material_type_id, unit_price, stock_quantity, min_quantity, package_quantity, unit) VALUES (16, 'Коробка подарочная малая', 9, 18.00, 420.0, 150.0, 50.0, 'шт');
INSERT INTO materials (id, name, material_type_id, unit_price, stock_quantity, min_quantity, package_quantity, unit) VALUES (17, 'Этикетка фирменная круглая', 10, 3.20, 1800.0, 500.0, 250.0, 'шт');
INSERT INTO materials (id, name, material_type_id, unit_price, stock_quantity, min_quantity, package_quantity, unit) VALUES (18, 'Наклейка предупреждающая', 10, 2.10, 1600.0, 400.0, 200.0, 'шт');

-- 4. Импорт продукции
INSERT INTO products (id, article, product_type_id, name, min_partner_price) VALUES (1, 'AR-001', 1, 'Свеча «Лавандовый вечер»', 980.00);
INSERT INTO products (id, article, product_type_id, name, min_partner_price) VALUES (2, 'AR-002', 1, 'Свеча «Ванильный крем»', 950.00);
INSERT INTO products (id, article, product_type_id, name, min_partner_price) VALUES (3, 'AR-003', 1, 'Свеча «Цитрусовый сад»', 970.00);
INSERT INTO products (id, article, product_type_id, name, min_partner_price) VALUES (4, 'AR-004', 2, 'Свеча «Белый мускус»', 1290.00);
INSERT INTO products (id, article, product_type_id, name, min_partner_price) VALUES (5, 'AR-005', 2, 'Свеча «Дикая орхидея»', 1360.00);
INSERT INTO products (id, article, product_type_id, name, min_partner_price) VALUES (6, 'AR-006', 4, 'Свеча «Теплый янтарь»', 1490.00);
INSERT INTO products (id, article, product_type_id, name, min_partner_price) VALUES (7, 'AR-007', 4, 'Свеча «Сандаловое дерево»', 1520.00);
INSERT INTO products (id, article, product_type_id, name, min_partner_price) VALUES (8, 'AR-008', 5, 'Мини-свеча «Лаванда»', 420.00);
INSERT INTO products (id, article, product_type_id, name, min_partner_price) VALUES (9, 'AR-009', 5, 'Мини-свеча «Ваниль»', 410.00);
INSERT INTO products (id, article, product_type_id, name, min_partner_price) VALUES (10, 'AR-010', 5, 'Мини-свеча «Цитрус»', 430.00);
INSERT INTO products (id, article, product_type_id, name, min_partner_price) VALUES (11, 'AR-011', 3, 'Набор «Уютный дом»', 2190.00);
INSERT INTO products (id, article, product_type_id, name, min_partner_price) VALUES (12, 'AR-012', 3, 'Набор «Теплый вечер»', 2340.00);
INSERT INTO products (id, article, product_type_id, name, min_partner_price) VALUES (13, 'AR-013', 6, 'Свеча «Зимние специи»', 1380.00);
INSERT INTO products (id, article, product_type_id, name, min_partner_price) VALUES (14, 'AR-014', 6, 'Свеча «Хвойный лес»', 1410.00);

-- 5. Импорт рецептур продукции
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (1, 1, 1, 0.180);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (2, 4, 1, 0.009);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (3, 9, 1, 1.000);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (4, 11, 1, 1.000);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (5, 17, 1, 1.000);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (6, 1, 2, 0.180);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (7, 5, 2, 0.010);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (8, 9, 2, 1.000);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (9, 11, 2, 1.000);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (10, 17, 2, 1.000);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (11, 2, 3, 0.175);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (12, 6, 3, 0.011);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (13, 9, 3, 1.000);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (14, 11, 3, 1.000);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (15, 17, 3, 1.000);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (16, 1, 4, 0.220);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (17, 5, 4, 0.006);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (18, 10, 4, 1.000);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (19, 12, 4, 1.000);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (20, 17, 4, 1.000);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (21, 1, 5, 0.225);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (22, 4, 5, 0.004);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (23, 10, 5, 1.000);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (24, 12, 5, 1.000);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (25, 17, 5, 1.000);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (26, 3, 6, 0.280);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (27, 7, 6, 0.004);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (28, 10, 6, 1.000);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (29, 13, 6, 1.000);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (30, 17, 6, 1.000);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (31, 3, 7, 0.285);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (32, 5, 7, 0.003);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (33, 10, 7, 1.000);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (34, 13, 7, 1.000);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (35, 17, 7, 1.000);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (36, 2, 8, 0.070);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (37, 4, 8, 0.003);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (38, 9, 8, 1.000);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (39, 11, 8, 1.000);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (40, 2, 9, 0.070);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (41, 5, 9, 0.003);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (42, 9, 9, 1.000);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (43, 11, 9, 1.000);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (44, 2, 10, 0.070);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (45, 6, 10, 0.003);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (46, 9, 10, 1.000);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (47, 11, 10, 1.000);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (48, 1, 11, 0.180);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (49, 4, 11, 0.009);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (50, 9, 11, 1.000);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (51, 11, 11, 1.000);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (52, 15, 11, 1.200);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (53, 16, 11, 1.000);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (54, 17, 11, 1.000);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (55, 1, 12, 0.225);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (56, 5, 12, 0.010);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (57, 10, 12, 1.000);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (58, 12, 12, 1.000);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (59, 15, 12, 1.500);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (60, 16, 12, 1.000);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (61, 17, 12, 1.000);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (62, 1, 13, 0.210);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (63, 5, 13, 0.008);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (64, 7, 13, 0.003);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (65, 10, 13, 1.000);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (66, 12, 13, 1.000);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (67, 18, 13, 1.000);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (68, 1, 14, 0.215);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (69, 6, 14, 0.004);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (70, 7, 14, 0.002);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (71, 10, 14, 1.000);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (72, 12, 14, 1.000);
INSERT INTO material_products (id, material_id, product_id, material_quantity) VALUES (73, 18, 14, 1.000);

SELECT setval('material_types_id_seq', (SELECT MAX(id) FROM material_types));
SELECT setval('product_types_id_seq', (SELECT MAX(id) FROM product_types));
SELECT setval('materials_id_seq', (SELECT MAX(id) FROM materials));
SELECT setval('products_id_seq', (SELECT MAX(id) FROM products));
SELECT setval('material_products_id_seq', (SELECT MAX(id) FROM material_products));
